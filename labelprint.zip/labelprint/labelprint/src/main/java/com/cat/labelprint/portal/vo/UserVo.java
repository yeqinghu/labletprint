package com.cat.labelprint.portal.vo;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@Accessors(chain = true)
public class UserVo implements Serializable {

    private Integer id;
    private String username;
    private String nickname;

    //用户的问题数
    private int questions;
    //用户的收藏数
    private int collections;
}
