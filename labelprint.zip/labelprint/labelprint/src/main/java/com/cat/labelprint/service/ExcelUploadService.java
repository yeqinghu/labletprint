package com.cat.labelprint.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;


@Transactional
public interface ExcelUploadService extends IService<Label> {
	Integer excelUpload(Label p);

}
