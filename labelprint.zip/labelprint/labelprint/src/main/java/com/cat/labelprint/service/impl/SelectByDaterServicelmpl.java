package com.cat.labelprint.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.service.ExcelUploadService;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class SelectByDaterServicelmpl  extends ServiceImpl<SelectAssemblyLinemapper, Label> implements SelectByDateService   {
	@Autowired
	SelectAssemblyLinemapper mapper;
	public PageInfo<Label> getById( String line,String date ,Integer pageNum,Integer pageSize) throws ServiceException  {		
		if(date.matches("\\d{2}-\\d{2}-\\d{4}")) {
			 throw new ServiceException("日期格式为MM-dd-yyyy");
		}
		PageHelper.startPage(pageNum, pageSize );
		List<Label> list = mapper.getById(line,date);
		 // 清理 ThreadLocal 存储的分页参数,保证线程安全
		PageHelper.clearPage(); 
		return new PageInfo<Label>(list) ;
	}
	  
}
