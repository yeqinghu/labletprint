package com.cat.labelprint.portal.vo;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
//支持实体类的链式函数(方法)
@Accessors(chain = true)
public class QuestionVo implements Serializable {

    @NotBlank(message = "标题不能为空")
    @Pattern(regexp = "^.{3,50}$",message = "标题要求3~50个字符")
    private String title;
    @NotBlank(message = "问题内容不能为空")
    private String content;

    @NotEmpty
    private String[] tagNames={};
    @NotEmpty
    private String[] teacherNicknames={};

}

