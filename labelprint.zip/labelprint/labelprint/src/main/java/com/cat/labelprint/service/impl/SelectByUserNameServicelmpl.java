package com.cat.labelprint.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.entity.User;
import com.cat.labelprint.mapper.SelectByUsernamemapper;
import com.cat.labelprint.service.ExcelUploadService;
import com.cat.labelprint.service.SelectByUserNameService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageHelper;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class SelectByUserNameServicelmpl  extends ServiceImpl< SelectByUsernamemapper, User> implements SelectByUserNameService   {
	@Autowired
	SelectByUsernamemapper mapper;
	 
	@Override
	public User SelectByUserName(String userName) {
		// TODO Auto-generated method stub
		User user=null;
		if(!"".equals(userName)) {
		  user=mapper.SelectByUname(userName);
		  if("".equals(user)) {
			  return null;
		  }else {
			  return user; 
		  }
		}else {
			return null;
		}
		
	}
	 
	  
}
