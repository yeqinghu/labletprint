package com.cat.labelprint.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.service.ExcelUploadService;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.SelectBySerialNumberService;
import com.cat.labelprint.service.SelectByTrackshoeService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageHelper;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class SelectBySerialNumberServicelmpl  extends ServiceImpl<SelectAssemblyLinemapper, Label> implements SelectBySerialNumberService   {
	@Autowired
	SelectAssemblyLinemapper mapper;
	 
	@Override
	public Label selectBySerialNumber(String SerialNumber) {
		if(SerialNumber==null)  {
			 throw new ServiceException("系列号不为空");
		}
		 
		 Label  Label = mapper.selectBySerialNumber(SerialNumber);
		return Label;
	}
	 
	  
}
