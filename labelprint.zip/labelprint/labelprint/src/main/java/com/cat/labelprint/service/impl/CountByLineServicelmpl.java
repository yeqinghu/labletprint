package com.cat.labelprint.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.CountByLinemapper;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.service.CountByLineService;
import com.cat.labelprint.service.ExcelUploadService;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class CountByLineServicelmpl  extends ServiceImpl<CountByLinemapper,Integer> implements CountByLineService   {
	@Autowired
	CountByLinemapper mapper;
	Integer num;//查询当天生产数量
	@Override
	public Integer countByLine(String line, String date)  {
		// TODO Auto-generated method stub
		try {
			if(line!=null&&date!=null) {
				 num=mapper.selectLine(line, date);
			
			}
		}
		catch (ServiceException e) {
			throw new ServiceException("查询数量有误");		
			}
		
		return num;
	}
	  
}
