package com.cat.labelprint.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cat.labelprint.entity.Label;
import com.github.pagehelper.PageInfo;

@Transactional
public interface SelectByDateService  extends IService<Label>   {
	  //List<Label> getById(String line) throws Exception ;

	PageInfo<Label> getById(String line,String date, Integer pageNum, Integer pageSize) ;
}
