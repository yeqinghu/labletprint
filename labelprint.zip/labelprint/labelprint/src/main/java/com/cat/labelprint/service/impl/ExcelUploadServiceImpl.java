package com.cat.labelprint.service.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.service.ExcelUploadService;

 
import lombok.extern.slf4j.Slf4j;

 
@Service
@Slf4j
public class ExcelUploadServiceImpl extends ServiceImpl<Labelmapper, Label> implements ExcelUploadService  {
	@Autowired
	Labelmapper labelmapper;

	@Override
	@Transactional//事务管理
	public Integer excelUpload(Label p) {
		int num=0;
		if(null!=p) {
			num=labelmapper.insert(p);
		}
		 
		return num;
	}

}
