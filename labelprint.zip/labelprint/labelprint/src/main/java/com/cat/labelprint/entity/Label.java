package com.cat.labelprint.entity;

 
import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import cn.afterturn.easypoi.excel.annotation.Excel;
 
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

 
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("labelproduct")
public class Label implements Serializable   {
	 
	
	@Excel(name="序号")
	@TableId(value="orderNumber",type=IdType.AUTO)
	private Integer orderNumber;
	
	@Excel(name="生产订单号")
	private String productionOrderNumber;
	
	@Excel(name="履带号")
	private String trackNumber;
	
	@Excel(name="型号")
	private String model;
	
	@Excel(name="装配线#")	
	private String assemblyLine;
	
	@Excel(name="工单总数数量")
	private Integer totalNumber;
	
	@Excel(name="开工日期",replace = {"/_-"},importFormat="MM-dd-yyyy")
	//@Pattern(regexp=DATE_REGEXP , message = " 错误")	
	private String commencementDate ;
	
	@Excel(name="喷漆完工日期",replace = {"/_-"},importFormat="MM-dd-yyyy",format="MM-dd-yyyy")	
	private String finishDatepainting;
	
	  @Excel(name="abc标识") private String abcIdentification;
	  
	  @Excel(name="班次") private String frequency;
	  
	  @Excel(name="履带板") private String trackShoe;
	  
	  @Excel(name="3位天数") private Integer threeDigitDays;
	  
	  @Excel(name="2位序号") private String serialTwoNumber;
	  
	  @Excel(name="系列号") private String serialNumber;
	  
	  @Excel(name="发货日期",replace = {"/_-"}) private String issuanceDate;
	  
	  @Excel(name="客户物料号") private String customerMaterialNumber;
	  
	  @Excel(name="间隔天数范围") private String intervalDaysRange;
	  
	   @Excel(name="CUXL公司名称") private String corporateNumber;
	   
	   @Excel(name="涂漆要求") private String paintingRequirements;
	   
	   @Excel(name="客户名称") private String customerName;
	   
	   @Excel(name="客户") private String customer;
	   
	   @Excel(name="joint") private Integer joint;
	   
	   @Excel(name="捆绑方式") private String bindingMode;
	   
	   @Excel(name="Remark") private Integer remark;
	   
	   @Excel(name="标签单位") private String labelNnit;
	   
	   @Excel(name="螺栓") private String bolt;
	   
	   @Excel(name="螺母") private String nut;
	   
	   @Excel(name="标准型号") private String standardModel;
	   
	   @Excel(name="主链节") private String mainLink;

	 

 
	
	
	
}
