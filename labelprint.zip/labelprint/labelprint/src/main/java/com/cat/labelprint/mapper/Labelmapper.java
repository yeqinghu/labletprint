package com.cat.labelprint.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
 

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cat.labelprint.entity.LabelEntity;
import com.cat.labelprint.entity.Label;
 

 

 
//extends BaseMapper<productionLabelEntity> 
@Mapper
@Repository
public interface Labelmapper extends BaseMapper<Label>   {
	
	
	//@Options(useGeneratedKeys=true ,keyProperty="orderNumber")
	//int inserts( @Param("trackNumber")String trackNumber,@Param("model")String model,@Param("assemblyLine")String assemblyLine);
	/*
	 * @Insert(
	 * {"insert into labelproduct (productionOrderNumber, trackNumber,model,assemblyLine) values (productionOrderNumber=#{productionOrderNumber}, trackNumber=#{trackNumber} ,model=#{model} ,assemblyLine=#{assemblyLine} ) "
	 * }) int insertlabel(productionLabelEntity entity);
	 */
	//没用到
	@Delete("Delete from labelproduct where orderNumber=#{orderNumber}")
	int deleteByid(Integer ord);
}
