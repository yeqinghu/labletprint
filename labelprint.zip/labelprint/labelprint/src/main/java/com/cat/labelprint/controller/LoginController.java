package com.cat.labelprint.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.entity.User;
import com.cat.labelprint.portal.vo.R;
import com.cat.labelprint.service.CountByLineService;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.SelectBySerialNumberService;
import com.cat.labelprint.service.SelectByTrackshoeService;
import com.cat.labelprint.service.SelectByUserNameService;
import com.cat.labelprint.service.ServiceException;

import lombok.extern.slf4j.Slf4j;
@Controller
@RestController
@Slf4j
public class LoginController {
	@Resource
	private SelectByDateService selectByorderService;
	@Resource
	private SelectByTrackshoeService selectbytrackshoe;
	@Resource
	private SelectBySerialNumberService selectByserialnumber;
	@Resource
	private CountByLineService countbyline;
	@Resource
	private SelectByUserNameService selectByUsername;
	@GetMapping("/login.html")
	public ModelAndView login (@ModelAttribute Label label,Model model ){
		 
		try {
			
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                 
		return  new ModelAndView("login");
		
	}	//访问comord.html页面
	@PostMapping("/index.html")
	public R<String> index (@RequestBody User user,Model model ){
		 System.out.println(user.getUserName());
		 System.out.println(user.getPassWord());
	User getUser =selectByUsername.SelectByUserName(user.getUserName());
		 if(getUser!=null) { 
			 System.out.println(getUser.toString());
			 if(getUser.getPassWord().equals(user.getPassWord())) {
				return R.ok("ok"); 
			 }else {
				 return R.unauthorized("密码错误！");
			 }
		 }else {
			 return R.unauthorized("用户名不存在");
			  }
	}
	@GetMapping("/ord-add.html")
	public ModelAndView memberadd (@ModelAttribute Label label,Model model ){
		 
		 
			 try {
				  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				 
			}
			return new ModelAndView("ord-add");	
	}
	 
	@GetMapping("/order-list.html")
	public ModelAndView orderlist (@ModelAttribute Label label,Model model ){
		 
		 
			 try {
				  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				 
			}
			return new ModelAndView("order-list");	
	}
	@GetMapping("/welcome.html") 
	public ModelAndView welcome (@ModelAttribute Label label,HttpServletRequest rq ){
		 			
		 
			 try {
				 Date d=new Date();	 
				 SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
				 String day=sdf .format(d);
				Integer line1= countbyline.countByLine("Line 1", day);
				Integer line2= countbyline.countByLine("Line 2", day);
				Integer line3= countbyline.countByLine("Line 3", day);
				Integer line4= countbyline.countByLine("Line 4", day);
				Integer line5= countbyline.countByLine("Line 5", day);
				 
				rq.setAttribute("line1", line1);
				rq.setAttribute("line2", line2);
				rq.setAttribute("line3", line3);
				rq.setAttribute("line4", line4);
				rq.setAttribute("line5", line5);
				
				  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				 
			}
			return new ModelAndView("welcome");	
	 
	}
	@GetMapping("/printpage.html")
	public ModelAndView printpage (String serialNumber,Model model ){
		System.out.println( serialNumber  );
		System.out.println("后台获得"+selectByserialnumber.selectBySerialNumber(serialNumber));	
		Label label=selectByserialnumber.selectBySerialNumber(serialNumber);
		
		
		 model.addAttribute("trackshoe", label );		 	 
		return new ModelAndView("printpage");
	}
	@GetMapping("/printtest.html")
	public ModelAndView printtable (String serialNumber,Model model ){
		System.out.println( serialNumber  );
		System.out.println("后台获得"+selectByserialnumber.selectBySerialNumber(serialNumber));	
		Label label=selectByserialnumber.selectBySerialNumber(serialNumber);
		
		
		 model.addAttribute("trackshoe", label );		 	 
		return new ModelAndView("printtest");
	}
	
	
	@GetMapping("/toindex.html")
	public ModelAndView toindex ( Model model ){
		 
		return new ModelAndView("index");
	}
 }
	
 
