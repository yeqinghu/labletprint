package com.cat.labelprint.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.baomidou.mybatisplus.extension.service.IService;
@Service
@Transactional
public interface CountByLineService  extends IService<Integer>   {
	  //List<Label> getById(String line) throws Exception ;

	 Integer countByLine(String line,String date )  ;
}
