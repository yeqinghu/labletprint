package com.cat.labelprint.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cat.labelprint.entity.Label;

@Mapper
public interface SelectAssemblyLinemapper  extends BaseMapper<Label> {
	//通过产品线号 或者完成时间查询
	@Select("SELECT assemblyLine, productionOrderNumber,commencementDate,issuanceDate,trackShoe,bolt,nut,finishDatepainting,serialNumber,paintingRequirements,bindingMode,customer,joint,mainLink,bindingMode,customerMaterialNumber FROM labelproduct WHERE assemblyLine=#{line} and commencementDate=#{commencementDate}")
	 List<Label> getById(String line,String commencementDate );
	
	//通过履带号查询
	@Select("SELECT assemblyLine, productionOrderNumber,commencementDate,trackShoe,bolt,nut,finishDatepainting,issuanceDate FROM labelproduct  "
			+ "WHERE trackShoe=#{trackShoe} ")
	 Label  selectBytrackShoe(String trackShoe );
	//通过系列号查询
		@Select("SELECT  assemblyLine, productionOrderNumber,commencementDate,trackShoe,bolt,nut,finishDatepainting,issuanceDate,serialNumber,paintingRequirements,bindingMode,customer,joint,mainLink,bindingMode,customerMaterialNumber FROM labelproduct  "
				+ "WHERE serialNumber=#{serialNumber} ")
		 Label  selectBySerialNumber(String serialNumber );
 
}
