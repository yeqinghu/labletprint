package com.cat.labelprint.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.service.ExcelUploadService;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.SelectByTrackshoeService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageHelper;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class SelectByTrackShoeServicelmpl  extends ServiceImpl<SelectAssemblyLinemapper, Label> implements SelectByTrackshoeService   {
	@Autowired
	SelectAssemblyLinemapper mapper;
	public  Label  selectBytrackShoe( String trackShoe )  {		
		if(trackShoe==null)  {
			 throw new ServiceException("履带板号不为空");
		}
		 
		 Label  Label = mapper.selectBytrackShoe(trackShoe);
		return Label;
	}
	 
	  
}
