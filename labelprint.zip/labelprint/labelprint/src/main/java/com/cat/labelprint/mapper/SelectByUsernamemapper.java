package com.cat.labelprint.mapper;

import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cat.labelprint.entity.User;

public interface SelectByUsernamemapper  extends BaseMapper<User> {

	@Select("SELECT username,password FROM t_user WHERE username=#{username}")
	User SelectByUname(String username);

}
