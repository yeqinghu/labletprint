package com.cat.labelprint.service;

import org.springframework.transaction.annotation.Transactional;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cat.labelprint.entity.User;
 
@Transactional
public interface SelectByUserNameService  extends IService<User>   {
	  //List<Label> getById(String line) throws Exception ;

	 User SelectByUserName(String userName);
}
