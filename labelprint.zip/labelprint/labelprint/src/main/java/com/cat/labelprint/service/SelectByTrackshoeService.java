package com.cat.labelprint.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cat.labelprint.entity.Label;
@Transactional
public interface SelectByTrackshoeService  extends IService<Label>   {
	  //List<Label> getById(String line) throws Exception ;

	 Label selectBytrackShoe(String trackShoe );
}
