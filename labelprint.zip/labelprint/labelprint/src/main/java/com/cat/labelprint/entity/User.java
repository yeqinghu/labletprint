package com.cat.labelprint.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;
import lombok.experimental.Accessors;
@Data
@Accessors(chain = true)
@TableName("t_user")
public class User implements Serializable {
	
	private String UserName;
	
	private String PassWord;
}
