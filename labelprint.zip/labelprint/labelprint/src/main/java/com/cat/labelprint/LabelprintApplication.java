package com.cat.labelprint;

import org.mybatis.spring.annotation.MapperScan;
		import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
		import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableTransactionManagement
@SpringBootApplication
@MapperScan("com.cat.labelprint.mapper")
@ComponentScan("com.cat.labelprint")
public class LabelprintApplication {


	public static void main(String[] args) {
		SpringApplication.run(LabelprintApplication.class, args);
	}
}
