package com.cat.labelprint.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.portal.vo.R;
import com.cat.labelprint.service.SelectByDateService;
import com.cat.labelprint.service.SelectByTrackshoeService;
import com.cat.labelprint.service.ServiceException;
import com.github.pagehelper.PageInfo;

import lombok.extern.slf4j.Slf4j;

@RestController
@Controller
@Slf4j
public class SelectController {
	@Resource
	private SelectByDateService selectbydate;
	@Resource
	private SelectByTrackshoeService selectbytrackshoe;
	@PostMapping("/selectbyline")
//	@ResponseBody
	//通过产品线查找
	public R<PageInfo<Label>> selectbyline( HttpServletRequest request,String date,  String line,  Integer pageNum,Model model ) throws Exception{
		// 为了程序的严谨性，判断非空：
		System.out.println("date"+date+"line"+line+"pageNum"+pageNum);
		System.out.println(date!=""&&date!=null);
		if (pageNum == null) {
			pageNum = 1; // 设置默认当前页
		}
		if (pageNum <= 0) {
			pageNum = 1;
		}
		Integer pageSize=null;
		if (pageSize == null) {
			pageSize = 8; // 设置默认每页显示的数据数
		}
 
		 
 		
 		if(date!=""&&date!=null  ) {
 		 Integer month=Integer.parseInt(date.substring(5,7));
 		 String year=date.substring(0,4);
 		 String day=date.substring(8);
 		 date=month+"-"+day+"-"+year;
 		}
 		PageInfo<Label> labels = null;
			//查询所有产线的记录
			 labels = selectbydate.getById(line,date,pageNum,pageSize);
			 System.out.println(labels.getPageNum());
			 //分页信息
			 model.addAttribute("pageInfo", labels);
			 return  R.ok( labels);
               
	}
	
	 
 
	
	
	
	
	
	
	
	
	
	//访问comord.html页面
	@RequestMapping(value = "/selectbytrackShoe")
	public  R<String> index(String trackShoe,Model model) {
		System.out.println("2222");
		System.out.println(trackShoe);
		 
		   try { 
			   System.out.println("bytrackShoe"+selectbytrackshoe.selectBytrackShoe( trackShoe)); 
			   model.addAttribute("trackshoe",JSON.toJSONString(selectbytrackshoe.selectBytrackShoe(trackShoe)));
			   } catch (Exception e) {
		       //TODO Auto-generated catch block throw new
		        //  ServiceException("userNumber绑定line有错误");
}
		  
		return R.ok("OK");
	}
	/*
	 * @RequestMapping(value = "/demo.html") public ModelAndView
	 * dodemo(@ModelAttribute Label label,Model model) {
	 * //这样的话，${user}才可在index.html中被取出 //model.addAttribute("userNumber", new
	 * Label()); try {
	 * //System.out.println(selectByorderService.getById("Line 1",1,11));
	 * //model.addAttribute("user",selectByorderService.getById("Line 1",1,11)); }
	 * catch (Exception e) { // TODO Auto-generated catch block throw new
	 * ServiceException("demo绑定user有错误"); } return new ModelAndView("doneord"); }
	 */
	}
 
	
 
