package com.cat.labelprint.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson.JSON;
import com.cat.labelprint.entity.Label;
import com.cat.labelprint.service.ExcelUploadService;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/excel") 
@Slf4j
public class ExcelController {
	@Autowired
	ExcelUploadService excelService;


	@RequestMapping("/demo")
	@ResponseBody
	public String demo(){
		log.debug("Hello World!");
		return "OK";
	}
	//用easyPOI导入excel
	@PostMapping("/upload")
	public String upload1(@RequestParam("file") MultipartFile multipartFile,Model model) throws Exception{
		ImportParams params = new ImportParams();
		/* params.setTitleRows(1); */
		params.setHeadRows(1);
		System.out.println("正在插入文件");
		//合规检验开启
		//params.setNeedVerfiy(true);
		List<Label> result=null;
		try {
			if(null!=multipartFile) {  
			   result = ExcelImportUtil.importExcel(multipartFile.getInputStream(),Label.class, params);
				System.out.println(JSON.toJSONString(result));
				if(result!=null) {
					for(Label s:result) {
						String date=s.getCommencementDate().replace("/", "-");
						SimpleDateFormat format=new SimpleDateFormat("MM-dd-yyyy");
						Date nowdate=new Date();
						 Date d2 = format.parse(format.format(nowdate));
						 System.out.println("时间戳"+d2);
						if(date.equals(d2.toString())) {
							s.setCommencementDate(date);
						
							//使用业务层	 
							excelService.excelUpload(s); 
							//labelmapper.insert(s);  
						}
						else {
							return "日期不是今天";
						}
					} 
					System.out.println("插入数据"+result.size());
				}
			}else {
				return "上传文件为空";
			}

		}catch (NoSuchElementException e) {
			throw new RuntimeException("Excelfile不能为空！");
		}catch (Exception e) {


		}

		return "已上传,插入数据"+result.size();
	}	   


}