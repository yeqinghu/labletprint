package com.cat.labelprint.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cat.labelprint.entity.Label;

@Mapper
public interface CountByLinemapper  extends BaseMapper<Integer> {
	//查询当天生产数量
	@Select("SELECT count(assemblyLine)   FROM labelproduct WHERE assemblyLine=#{line} and commencementDate=#{commencementDate}")
	Integer selectLine(String line,String commencementDate );
	 
}
