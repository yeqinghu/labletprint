package com.cat.labelprint.labelprint;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;

import com.cat.labelprint.entity.LabelEntity;
import com.cat.labelprint.entity.User;
import com.cat.labelprint.entity.Label;
 
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.mapper.SelectByUsernamemapper;
import com.github.pagehelper.PageHelper;


@SpringBootTest
class LabelprintApplicationTests {
	@Autowired
	Labelmapper mapper;
	@Autowired
	DataSourceTransactionManager dataSourceTransactionManager;
	@Autowired
	TransactionDefinition transactionDefinition;
	@Autowired
	SelectAssemblyLinemapper selectmapper;
	@Autowired
	SelectByUsernamemapper umapper;
	@Test
	void contextLoads() {
		 TransactionStatus transactionStatus = dataSourceTransactionManager.getTransaction(transactionDefinition);
		Label pd= new Label();
		pd.setProductionOrderNumber("132000230161"); 
		pd.setTrackNumber("5915644/HE");
		pd.setModel("313GX");
		pd.setAssemblyLine("Line 2");
		System.out.println(pd.toString());
		int num=mapper.insert(pd);
		dataSourceTransactionManager.commit(transactionStatus);
		//int num=mapper.inserts("5915645/HE","313GX","Line 1");
		System.out.println(num);
	}
	@Test
	  void delectall() {
		int num=mapper.deleteByid(9);
		System.out.println("002"+num);
		 
		 
	}
	@Test
	void insertuse() {
		/*
		 * int num; for(int i=0;i<16;i++) { userEntity user=new userEntity();
		 * user.setUsername("沙僧"+i); user.setPassword("123"); user.setAge(351);
		 * user.setPhone("122"); user.setEmail("122@qq.com"); //
		 * num=newmapper.insert(user); //System.out.println("OK"+num); }
		 */
		 
	}
	@Test
	void selectByorder () {
		/*
		 * int num; for(int i=0;i<16;i++) { userEntity user=new userEntity();
		 * user.setUsername("沙僧"+i); user.setPassword("123"); user.setAge(351);
		 * user.setPhone("122"); user.setEmail("122@qq.com"); //
		 * num=newmapper.insert(user); //System.out.println("OK"+num); }
		 */ 
		 Label list=selectmapper.selectBySerialNumber("5915645/HEAB120A01");
		System.err.println(list);
		/*
		 * for (Label l :list) { System.out.println(l); }
		 */
		  
		 
	}
	@Test
	void selectuname() {
		User user=umapper.SelectByUname("sys");
		System.out.println(user.toString());
		
		/*
		 * int num; for(int i=0;i<16;i++) { userEntity user=new userEntity();
		 * user.setUsername("沙僧"+i); user.setPassword("123"); user.setAge(351);
		 * user.setPhone("122"); user.setEmail("122@qq.com"); //
		 * num=newmapper.insert(user); //System.out.println("OK"+num); }
		 */
		//String num=mapper.getById(50);
		 
		//	System.out.println(num);
		 //执行分页查询
        
       
		//List<Label> la=selectmapper.getById("Line 1");
		 
		 
	}

}
