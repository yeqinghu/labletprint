package com.cat.labelprint.labelprint;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;

import com.cat.labelprint.entity.Label;
import com.cat.labelprint.mapper.Labelmapper;
import com.cat.labelprint.mapper.SelectAssemblyLinemapper;
import com.cat.labelprint.service.CountByLineService;
import com.cat.labelprint.service.SelectByDateService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@SpringBootTest
public class labeltest {
	@Autowired
	Labelmapper mapper;
	@Autowired
	DataSourceTransactionManager dataSourceTransactionManager;
	@Autowired
	TransactionDefinition transactionDefinition;
	@Autowired
	SelectAssemblyLinemapper selectmapper;
	@Autowired
	SelectByDateService sbs;
	@Autowired
	CountByLineService cbs;
		@Test
		 void select() {
		
	 
		/*
		 * int num; for(int i=0;i<16;i++) { userEntity user=new userEntity();
		 * user.setUsername("沙僧"+i); user.setPassword("123"); user.setAge(351);
		 * user.setPhone("122"); user.setEmail("122@qq.com"); //
		 * num=newmapper.insert(user); //System.out.println("OK"+num); }
		 */
		//String num=mapper.getById(50);
		 
		//	System.out.println(num);
		 //执行分页查询
        //PageHelper.startPage(1,6);
       
		PageInfo<Label> la;
		try {
			 PageHelper.startPage(1, 6 );
			 la = sbs.getById("Line 1","5-02-2021", 1, 11);
				 System.err.println("1111"+la);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		 
		 @Test
		 void count() {
				Date date=new Date();
				DateFormat format=new SimpleDateFormat("MM-dd-yyyy");
				String day=format.format(date);
				System.out.println(day);
				Integer i= cbs.countByLine("Line 1", day);
				System.out.println(i);
		 }
		 @Test
		 void count1() {
			 Date d=new Date();	 
			 SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
			 String day=sdf .format(d);
			Integer i= cbs.countByLine("Line 1", day);
			System.out.println(i);
		 }
		
}
